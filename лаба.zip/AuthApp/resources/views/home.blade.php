@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                  <table style="width:100%">
  <tr>
    <th>Authorization historye</th>
    
  </tr>
  @foreach ($selection as $item)
  <tr>
  <td>{{$item->time}}</td>
  </tr>
  <tr>
  <td>{{$item->ip}}</td>
  </tr>
  
  @endforeach
</table>
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                              
          
        </div>
   
   
    </div>
</div>
@endsection
